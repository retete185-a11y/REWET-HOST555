const { pool, query } = require('./db');

function normalizeCode(code) {
    return String(code || '').trim().toUpperCase();
}

function validateCode(code) {
    if (!/^[A-Z0-9_-]{3,32}$/.test(code)) {
        throw new Error('Промокод: 3–32 символа, только A-Z, 0-9, _ и -.');
    }
}

function parsePositiveInt(value, field, max) {
    const number = Number(value);
    if (!Number.isInteger(number) || number <= 0 || number > max) {
        throw new Error(`${field} должен быть целым числом от 1 до ${max}`);
    }
    return number;
}

async function createPromoCode(code, amount, maxUses) {
    const normalized = normalizeCode(code);
    validateCode(normalized);
    const promoAmount = parsePositiveInt(amount, 'Сумма', 1000000);
    const usesLimit = parsePositiveInt(maxUses, 'Лимит использований', 1000000);

    try {
        const result = await query(
            `INSERT INTO promo_codes (code, amount, max_uses, uses, active)
             VALUES ($1, $2, $3, 0, TRUE)
             RETURNING id, code, amount, max_uses, uses, active, created_at`,
            [normalized, promoAmount, usesLimit]
        );
        return result.rows[0];
    } catch (error) {
        if (error.code === '23505') {
            throw new Error('Такой промокод уже существует');
        }
        throw error;
    }
}

async function listPromoCodes() {
    const result = await query(
        `SELECT id, code, amount, max_uses, uses, active, created_at
         FROM promo_codes
         ORDER BY id DESC`
    );
    return result.rows;
}

async function setPromoActive(id, active) {
    const promoId = Number(id);
    if (!Number.isInteger(promoId) || promoId <= 0) {
        throw new Error('Некорректный ID промокода');
    }

    const result = await query(
        `UPDATE promo_codes SET active = $1 WHERE id = $2
         RETURNING id, code, amount, max_uses, uses, active, created_at`,
        [Boolean(active), promoId]
    );

    if (!result.rows.length) throw new Error('Промокод не найден');
    return result.rows[0];
}

async function deletePromoCode(id) {
    const promoId = Number(id);
    if (!Number.isInteger(promoId) || promoId <= 0) {
        throw new Error('Некорректный ID промокода');
    }

    const result = await query(
        `DELETE FROM promo_codes WHERE id = $1 RETURNING id, code`,
        [promoId]
    );

    if (!result.rows.length) throw new Error('Промокод не найден');
    return result.rows[0];
}

async function redeemPromoCode(userId, code) {
    const normalized = normalizeCode(code);
    validateCode(normalized);

    const client = await pool.connect();

    try {
        await client.query('BEGIN');

        const promoResult = await client.query(
            `SELECT id, code, amount, max_uses, uses, active
             FROM promo_codes
             WHERE code = $1
             FOR UPDATE`,
            [normalized]
        );

        if (!promoResult.rows.length) throw new Error('Промокод не найден');

        const promo = promoResult.rows[0];
        if (!promo.active) throw new Error('Промокод отключён');
        if (promo.uses >= promo.max_uses) throw new Error('Лимит использований промокода исчерпан');

        const usedResult = await client.query(
            `SELECT id FROM promo_uses WHERE promo_id = $1 AND user_id = $2`,
            [promo.id, userId]
        );

        if (usedResult.rows.length) throw new Error('Ты уже использовал этот промокод');

        await client.query(
            `INSERT INTO promo_uses (promo_id, user_id) VALUES ($1, $2)`,
            [promo.id, userId]
        );

        const balanceResult = await client.query(
            `UPDATE users
             SET balance = balance + $1
             WHERE id = $2
             RETURNING balance`,
            [promo.amount, userId]
        );

        if (!balanceResult.rows.length) throw new Error('Пользователь не найден');

        await client.query(
            `UPDATE promo_codes SET uses = uses + 1 WHERE id = $1`,
            [promo.id]
        );

        await client.query('COMMIT');

        return {
            code: promo.code,
            amount: promo.amount,
            balance: balanceResult.rows[0].balance
        };
    } catch (error) {
        await client.query('ROLLBACK');
        if (error.code === '23505') {
            throw new Error('Ты уже использовал этот промокод');
        }
        throw error;
    } finally {
        client.release();
    }
}

module.exports = {
    createPromoCode,
    listPromoCodes,
    setPromoActive,
    deletePromoCode,
    redeemPromoCode
};
